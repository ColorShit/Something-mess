using System.Collections;
using System.Collections.Generic;

using TMPro;

using UnityEngine;
using UnityEngine.UI;

public class RayTouch : MonoBehaviour
{
    public TextMeshProUGUI[] debugMsgs;
    public Button switchChildMode, clearBtn;
    private int[] debugMsgIndexes;
    bool childMode;
    private void Awake()
    {
        debugMsgIndexes = new int[6];
        childMode = true;
    }

    private void Start()
    {
        switchChildMode.onClick.AddListener(() => { childMode = !childMode; Clear(); });
        clearBtn.onClick.AddListener(Clear);
    }
    void Clear()
    {
        debugMsgIndexes = new int[6];
        foreach (TextMeshProUGUI i in debugMsgs) 
        {
            i.text = "Waiting...!";
        }
    }
    // Update is called once per frame
    void Update()
    {
        if (childMode)
        {
            if (Input.GetMouseButton(0))
            {
                debugMsgIndexes[0]++;
                debugMsgs[0].text = $"Left mouse button has touch {debugMsgIndexes[0]}!";
            }
            if (Input.GetMouseButtonDown(0))
            {
                debugMsgIndexes[1]++;
                debugMsgs[1].text = $"Left mouse button has down {debugMsgIndexes[1]}!";
            }
            if (Input.GetMouseButtonUp(0))
            {
                debugMsgIndexes[2]++;
                debugMsgs[2].text = $"Left mouse button has up {debugMsgIndexes[2]}!";
            }
            if (Input.GetMouseButton(1))
            {
                debugMsgIndexes[3]++;
                debugMsgs[3].text = $"Right mouse button has touch {debugMsgIndexes[3]}!";
            }
            if (Input.GetMouseButtonDown(1))
            {
                debugMsgIndexes[4]++;
                debugMsgs[4].text = $"Right mouse button has down {debugMsgIndexes[4]}!";
            }
            if (Input.GetMouseButtonUp(1))
            {
                debugMsgIndexes[5]++;
                debugMsgs[5].text = $"Right mouse button has up {debugMsgIndexes[5]}!";
            }
        }
        else
        {
            if (Input.GetMouseButton(0))
            {
                debugMsgIndexes[0]++;
                debugMsgs[0].text = $"Left mouse button has touch {debugMsgIndexes[0]}!";
            }
            else if (Input.GetMouseButtonDown(0))
            {
                debugMsgIndexes[1]++;
                debugMsgs[1].text = $"Left mouse button has down {debugMsgIndexes[1]}!";
            }
            else if(Input.GetMouseButtonUp(0))
            {
                debugMsgIndexes[2]++;
                debugMsgs[2].text = $"Left mouse button has up {debugMsgIndexes[2]}!";
            }
            if (Input.GetMouseButton(1))
            {
                debugMsgIndexes[3]++;
                debugMsgs[3].text = $"Right mouse button has touch {debugMsgIndexes[3]}!";
            }
            else if (Input.GetMouseButtonDown(1))
            {
                debugMsgIndexes[4]++;
                debugMsgs[4].text = $"Right mouse button has down {debugMsgIndexes[4]}!";
            }
            else if(Input.GetMouseButtonUp(1))
            {
                debugMsgIndexes[5]++;
                debugMsgs[5].text = $"Right mouse button has up {debugMsgIndexes[5]}!";
            }
        }
    }
}
