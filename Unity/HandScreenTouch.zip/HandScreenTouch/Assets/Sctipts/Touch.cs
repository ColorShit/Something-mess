using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class Touch : MonoBehaviour, IPointerClickHandler, IPointerDownHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler
{
    public TextMeshProUGUI click, down, up, enter, exit;
    private int clickIndex, downIndex, upIndex, enterIndex, exitIndex;
    public Button clearBtn;
    private void Awake()
    {
        clickIndex = 0;
        downIndex = 0;
        upIndex = 0;
        enterIndex = 0;
        exitIndex = 0;
    }
    private void Start()
    {
        clearBtn.onClick.AddListener(Clear);
    }
    public void OnPointerClick(PointerEventData eventData)
    {
        clickIndex++;
        click.text = $"click has happened {clickIndex}!";
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        downIndex++;
        down.text = $"down has happened {downIndex}!";
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        enterIndex++;
        enter.text = $"enter has happened {enterIndex}!";
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        exitIndex++;
        exit.text = $"exit has happened {exitIndex}!";
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        upIndex++;
        up.text = $"up has happened {upIndex}!";
    }

    public void Clear()
    {
        clickIndex = 0;
        downIndex = 0;
        upIndex = 0;
        enterIndex = 0;
        exitIndex = 0;
        click.text = "Waiting...!";
        down.text = "Waiting...!";
        up.text = "Waiting...!"; ;
        enter.text = "Waiting...!"; ;
        exit.text = "Waiting...!"; ;
    }
}
