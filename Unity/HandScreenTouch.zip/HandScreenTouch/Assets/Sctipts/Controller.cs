using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Controller : MonoBehaviour
{
    public Button go2, go1, quit, go3dScene;
    public GameObject part1, part2;
    public void Start()
    {
        go1.onClick.AddListener(() => { part2.SetActive(false); part1.SetActive(true); });
        go2.onClick.AddListener(() => { part1.SetActive(false); part2.SetActive(true); });
        quit.onClick.AddListener(Application.Quit);
        go3dScene.onClick.AddListener(() => { SceneManager.LoadScene(1); });
    }
}
