using System;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Observe : MonoBehaviour
{
    public Button goBack, exit;
    public GameObject obj, objChild;
    int rotateSpeed;
    public TMP_InputField inputField;
    public TextMeshProUGUI value, xAxisValue, yAxisValue, twoFingerDis, leftTouchedText, rightTouchedText, touchedCountText;
    // Start is called before the first frame update
    void Start()
    {
        rotateSpeed = 100;
        isRotate = false;
        goBack.onClick.AddListener(() => SceneManager.LoadScene(0));
        exit.onClick.AddListener(Application.Quit);
    }

    public void ContentChange(string content)
    {
        rotateSpeed = Convert.ToInt32(content);
    }

    bool isRotate;
    Vector2 initPos;
    float initialDistance;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            isRotate = true;
            initPos = Input.mousePosition;
        }
        else if (Input.GetMouseButtonUp(0))
        {
            isRotate = false;
            value.text = Vector2.Distance(initPos, Input.mousePosition).ToString("F1");
        }
        if (isRotate)
        {
            touchedCountText.text = Input.touchCount.ToString();
            if (Input.touchCount > 0)
            {
                if (Input.touchCount == 2)
                {
                    UnityEngine.Touch touch1 = Input.GetTouch(0);
                    UnityEngine.Touch touch2 = Input.GetTouch(1);
                    leftTouchedText.text = touch1.phase.ToString();
                    rightTouchedText.text = touch2.phase.ToString();
                    if (touch1.phase == TouchPhase.Began || touch2.phase == TouchPhase.Began)
                    {
                        initialDistance = Vector2.Distance(touch1.position, touch2.position);
                    }
                    else if (touch1.phase == TouchPhase.Moved && touch2.phase == TouchPhase.Moved)
                    {
                        float currentDistance = Vector2.Distance(touch1.position, touch2.position);
                        float deltaDistance = currentDistance - initialDistance;
                        twoFingerDis.text = deltaDistance.ToString("F1");
                        Camera.main.fieldOfView = CheckFOValue(Camera.main.fieldOfView - (deltaDistance * 0.01f * 10));
                        initialDistance = currentDistance;
                    }
                }
                else
                {
                    UnityEngine.Touch touch = Input.GetTouch(0);
                    leftTouchedText.text = touch.phase.ToString();
                    switch (touch.phase)
                    {
                        case TouchPhase.Moved:
                            float deltaX = touch.deltaPosition.x;
                            float deltaY = touch.deltaPosition.y;
                            xAxisValue.text = (deltaX * 5).ToString("F1");
                            yAxisValue.text = (deltaY * 5).ToString("F1");
                            obj.transform.Rotate(new Vector3(deltaY, 0, 0), Space.Self);
                            objChild.transform.Rotate(new Vector3(0, -deltaX, 0), Space.World);
                            break;
                        case TouchPhase.Began:
                            break;
                        case TouchPhase.Stationary:
                            break;
                        case TouchPhase.Ended:
                            break;
                        case TouchPhase.Canceled:
                            break;
                        default:
                            break;
                    }
                }
            }
            else
            {
                float xRot = Input.GetAxis("Mouse X") * Time.deltaTime * 500 * 3;
                float yRot = Input.GetAxis("Mouse Y") * Time.deltaTime * 500 * 3;
                xAxisValue.text = (xRot * 5).ToString("F1");
                yAxisValue.text = (yRot * 5).ToString("F1");

                obj.transform.Rotate(new Vector3(yRot, 0, 0), Space.Self);
                objChild.transform.Rotate(new Vector3(0, -xRot, 0), Space.World);
            }
            
        }
        float CheckFOValue(float value)
        {
            return Mathf.Min(Mathf.Max(value, 30), 90);
        }
    }
}
